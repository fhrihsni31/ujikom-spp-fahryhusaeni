<div class="container mt-3">
<div class="row">
<div class="col-12">
<center>
<h1 class="display-8">Pembayaran SPP</h1>
<h1 class="display-8">SMK SANGKURIANG 1 CIMAHI</h1>
<p class="lead"></p>
<hr class="my-4">
</center>
</div>
</div>


<div class="container pt-5">
<div class="row justify-content-center">
<div class="col-4">
<div class="card">
<img src="image/logo.png" >
    <div class="card-header">Login Siswa</div>
    <div class="card-body">
    <form action="index.php?aksi=loginsiswa" method="post">
    <div class="form-group">
        <label>NISN</label>
        <input type="text" class="form-control" name="nisn">
</div>
<div class="form-group">
    <label>NIS</label>
    <input type="text" class="form-control" name="nis">
</div>
<button class="btn btn-dark btn-sm" id="loginB">Masuk</button>
</form>
</div>
</div>
</div>
</div>  
</div>
</div>