<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-6">
        <form action="admin.php?page=insertpetugas" method="post">
   <div class="form-group">
        <label>username</label>
        <input type="text" name="username" class="form-control">
    </div>
    <div class="form-group">
        <label>password</label>
        <input type="password" name="password" class="form-control">
    </div>
    <div class="form-group">
        <label>nama petugas</label>
        <input type="text" name="nama_petugas" class="form-control">
    </div>
    <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
   </form>
        </div>
    </div>
</div>