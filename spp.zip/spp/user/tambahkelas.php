<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-6">
        <form action="admin.php?page=insertkelas" method="post">
   <div class="form-group">
        <label>Nama kelas</label>
        <input type="text" name="nama_kelas" class="form-control">
    </div>
    <div class="form-group">
        <label>kompetensi keahlian</label>
        <input type="text" name="kompetensi_keahlian" class="form-control">
    </div>
    <button type="submit" name="submit" class="btn btn-primary btn-sm">Submit</button>
   </form>
        </div>
    </div>
</div>