<div class="container mt-3">
<div class="row">
<div class="col-12">
<center>
<h1 class="display-8">Pembayaran SPP</h1>
<h1 class="display-8">SMK SANGKURIANG 1 CIMAHI</h1>
<p class="lead"></p>
<hr class="my-4">
</center>
</div>
</div>


<div class="container pt-5">
<div class="row justify-content-center">
<div class="col-4">
<div class="card">
    <img src="image/logo.png" >
    <div class="card-header">Login Petugas</div>
    <div class="card-body">
    <form action="index.php?aksi=login" method="post">
    <div class="form-group">
        <label>Username</label>
        <input type="text" class="form-control" name="username">
</div>
<div class="form-group">
    <label>Password</label>
    <input type="password" class="form-control" name="password">
</div>
<button class="btn btn-primary btn-sm" id="loginB">Masuk</button>
</form>
</div>
</div>
</div>
</div>  
</div>
</div>