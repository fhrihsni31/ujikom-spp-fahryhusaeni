<footer>
    <div class="container pt-5">
    <div class="mt-5">
    <nav class="navbar navbar-expland-Ig navbar-dark bg-dark fixed-bottom mt-5">
        <div class="container">
            <center>
            <p class="text-light pt-3">Copyright © <?php echo date('D-M-Y');?> SPP</p>
            </center>
</nav>
</div>
</footer>
<script src="js/jquery.slim.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</body>
</html>
